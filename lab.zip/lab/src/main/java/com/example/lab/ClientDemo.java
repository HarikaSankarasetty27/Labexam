package com.example.lab;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

	public class ClientDemo {
	    public static void main(String[] args) {
	        // Load Spring configuration
	        ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");

	        // Retrieve Employee bean
	        Employee employee = (Employee) context.getBean("employee");
	        System.out.println("Employee Details: " + employee);

	        // Retrieve Course bean
	        Course course = (Course) context.getBean("course");
	        System.out.println("Course Details: " + course);
	    }
	}

