package com.example.lab;

import java.util.ArrayList;
import java.util.Collection;

public class Employee 
{
	int employeeId;
	String name;
	double salary;
	String department; 
    Collection<String> skills = new ArrayList<>();

}
