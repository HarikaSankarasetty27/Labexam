package com.example.lab;

public class Course 
{
	int courseId;
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public double getCredits() {
		return credits;
	}
	public void setCredits(double credits) {
		this.credits = credits;
	}
	String courseName;
	double credits;
	private String instructor;
	
	@Override
    public String toString() {
        return "Course [courseId=" + courseId + ", courseName=" + courseName + 
               ", credits=" + credits + ", instructor=" + instructor + "]";
	}
}
