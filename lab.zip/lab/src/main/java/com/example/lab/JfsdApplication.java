package com.example.lab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JfsdApplication {

	public static void main(String[] args) {
		SpringApplication.run(JfsdApplication.class, args);
	}

}
